from django.db import models

# Create your models here.


class Contact(models.Model):
    name = models.CharField(max_length=100, null=True)
    email = models.EmailField(max_length=100, null=True)
    subject = models.CharField(max_length=15, null=True)
    massage = models.TextField(max_length=1000, null=True)

    def __str__(self):
        return self.email


class MailList(models.Model):
    email = models.EmailField(max_length=100, null=True)

    def __str__(self):
        return self.email


class Portfolio(models.Model):
    portfolio_id = models.IntegerField(name="portfolio_id")
    title = models.TextField(name="title", max_length=100)
    description = models.TextField(name="description", max_length=1500)
    image = models.TextField(name="image", max_length=1500, null=True)
    client = models.TextField(name="client", max_length=150, null=True)
    created_by = models.TextField(name="created_by", max_length=150, null=True)
    start_date = models.TextField(name="start_date", max_length=150, null=True)
    end_date = models.TextField(name="end_date", max_length=150, null=True)

    def __str__(self):
        return self.title
